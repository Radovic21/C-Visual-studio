﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Vozila_Projekat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vozila_dbDataSet.Table_Vozila' table. You can move, or remove it, as needed.
            this.table_VozilaTableAdapter.Fill(this.vozila_dbDataSet.Table_Vozila);

        }

        private void dodajButton_Click(object sender, EventArgs e)
        {
            // Zaključaj tabelu
            table_VozilaDataGridView.Enabled = false;

            if (kategorijaComboBox.Text == "-Izaberite kategoriju-" || markaTextBox.Text == "" ||
                modelTextBox.Text == "" || tezinaTextBox.Text == "" || cenaTextBox.Text == "" || datum_dolaskaDateTimePicker.Checked == false)
            {
                // MessageBox - Nije završen unos podataka
                string msg = "Nije završen unos podataka1";
                string caption = "Greška";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon ico = MessageBoxIcon.Error;

                MessageBox.Show(this, msg, caption, buttons, ico);
            }

            else
            {
                this.table_VozilaBindingSource.AddNew();

                // Vraća kategorijaComboBox u početno stanje
                kategorijaComboBox.SelectedIndex = 0;

                // Vraća DateTimePicker u početno stanje 
                datum_dolaskaDateTimePicker.Checked = false;
            }
        }

        private void izbrisiButton_Click(object sender, EventArgs e)
        {
            try
            {
                // MessageBox - Brisanje proizvoda
                string msg = "Da li želite da izbrišete izabrano vozilo?";
                string caption = "Brisanje";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon ico = MessageBoxIcon.Question;

                DialogResult result;

                result = MessageBox.Show(this, msg, caption, buttons, ico);

                if (result == DialogResult.Yes)
                {
                    // Brisanje
                    this.table_VozilaBindingSource.RemoveCurrent();

                    // Sačuvanje izmena
                    this.table_VozilaBindingSource.EndEdit();
                    this.table_VozilaTableAdapter.Update(this.vozila_dbDataSet.Table_Vozila);

                    // Osvežavanje podataka
                    this.table_VozilaTableAdapter.Fill(this.vozila_dbDataSet.Table_Vozila);

                    // Otključaj tabelu
                    table_VozilaDataGridView.Enabled = true;

                    MessageBox.Show("Vozilo je uspešno izbrisano.", "Brisanje", MessageBoxButtons.OK, MessageBoxIcon.Information);   
                }

                else
                {
                    return;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Došlo je do greške: " + ex.Message.ToString(), "Brisanje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void sacuvajButton_Click(object sender, EventArgs e)
        {

            if (kategorijaComboBox.Text == "-Izaberite kategoriju-" || markaTextBox.Text == "" ||
                modelTextBox.Text == "" || tezinaTextBox.Text == "" || cenaTextBox.Text == "" || datum_dolaskaDateTimePicker.Checked == false)
            {
                // MessageBox - Nisu uneti svi podaci
                string msg = "Niste uneli sve podatke!";
                string caption = "Greška";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon ico = MessageBoxIcon.Error;

                MessageBox.Show(this, msg, caption, buttons, ico);
            }

            else
            {
                try
                {
                    // MessageBox - Sačuvanje
                    string msg = "Da li želite da sačuvate?";
                    string caption = "Sačuvanje";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    MessageBoxIcon ico = MessageBoxIcon.Question;

                    DialogResult result;

                    result = MessageBox.Show(this, msg, caption, buttons, ico);

                    if (result == DialogResult.Yes)
                    {
                        // Sačuvaj
                        this.table_VozilaBindingSource.EndEdit();
                        this.table_VozilaTableAdapter.Update(this.vozila_dbDataSet.Table_Vozila);

                        // Osveži
                        this.table_VozilaTableAdapter.Fill(this.vozila_dbDataSet.Table_Vozila);

                        // Otključaj tabelu
                        table_VozilaDataGridView.Enabled = true;

                        MessageBox.Show("Izmene su sačuvane.", "Sačuvanje", MessageBoxButtons.OK, MessageBoxIcon.Information);    
                    }

                    else
                    {
                        return;
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Došlo je do greške: " + ex.Message.ToString(), "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void exportButton_Click(object sender, EventArgs e)
        {
            // SaveFileDialog
            SaveFileDialog sfd = new SaveFileDialog();

            sfd.FileName = "vozila fajl";
            sfd.DefaultExt = "txt";
            sfd.Filter = "txt files (*.txt)|*.txt";


            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (Stream s = File.Open(sfd.FileName, FileMode.Create))
                {
                    using (StreamWriter sw = new StreamWriter(s))
                    {
                        for (int i = 0; i < table_VozilaDataGridView.Rows.Count - 1; i++)
                        {
                            for (int j = 0; j < table_VozilaDataGridView.Columns.Count; j++)
                            {
                                sw.Write(" " + table_VozilaDataGridView.Rows[i].Cells[j].Value.ToString() + " " + "|");
                            }

                            sw.WriteLine("");
                            sw.WriteLine("------------------------------------------------------------------------------");
                        }

                        sw.Close();
                    }
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // MessageBox - Zatvaranje programa
            string msg = "Da li želite da zatvorite program?";
            string caption = "Zatvaranje";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            MessageBoxIcon ico = MessageBoxIcon.Question;

            DialogResult result;

            result = MessageBox.Show(this, msg, caption, buttons, ico);

            if (result == DialogResult.Yes)
            {
                // Zatvaranje prozora
                e.Cancel = false;
            }

            else
            {
                e.Cancel = true;
            }
        }
    }
}

﻿namespace Vozila_Projekat
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label kategorijaLabel;
            System.Windows.Forms.Label markaLabel;
            System.Windows.Forms.Label modelLabel;
            System.Windows.Forms.Label težinaLabel;
            System.Windows.Forms.Label cenaLabel;
            System.Windows.Forms.Label datum_dolaskaLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.vozila_dbDataSet = new Vozila_Projekat.vozila_dbDataSet();
            this.table_VozilaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.table_VozilaTableAdapter = new Vozila_Projekat.vozila_dbDataSetTableAdapters.Table_VozilaTableAdapter();
            this.tableAdapterManager = new Vozila_Projekat.vozila_dbDataSetTableAdapters.TableAdapterManager();
            this.table_VozilaBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.table_VozilaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.markaTextBox = new System.Windows.Forms.TextBox();
            this.modelTextBox = new System.Windows.Forms.TextBox();
            this.tezinaTextBox = new System.Windows.Forms.TextBox();
            this.cenaTextBox = new System.Windows.Forms.TextBox();
            this.datum_dolaskaDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dodajButton = new System.Windows.Forms.Button();
            this.izbrisiButton = new System.Windows.Forms.Button();
            this.sacuvajButton = new System.Windows.Forms.Button();
            this.exportButton = new System.Windows.Forms.Button();
            this.kategorijaComboBox = new System.Windows.Forms.ComboBox();
            kategorijaLabel = new System.Windows.Forms.Label();
            markaLabel = new System.Windows.Forms.Label();
            modelLabel = new System.Windows.Forms.Label();
            težinaLabel = new System.Windows.Forms.Label();
            cenaLabel = new System.Windows.Forms.Label();
            datum_dolaskaLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.vozila_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.table_VozilaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.table_VozilaBindingNavigator)).BeginInit();
            this.table_VozilaBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table_VozilaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kategorijaLabel
            // 
            kategorijaLabel.AutoSize = true;
            kategorijaLabel.Location = new System.Drawing.Point(12, 57);
            kategorijaLabel.Name = "kategorijaLabel";
            kategorijaLabel.Size = new System.Drawing.Size(76, 17);
            kategorijaLabel.TabIndex = 4;
            kategorijaLabel.Text = "Kategorija:";
            // 
            // markaLabel
            // 
            markaLabel.AutoSize = true;
            markaLabel.Location = new System.Drawing.Point(12, 85);
            markaLabel.Name = "markaLabel";
            markaLabel.Size = new System.Drawing.Size(51, 17);
            markaLabel.TabIndex = 6;
            markaLabel.Text = "Marka:";
            // 
            // modelLabel
            // 
            modelLabel.AutoSize = true;
            modelLabel.Location = new System.Drawing.Point(12, 113);
            modelLabel.Name = "modelLabel";
            modelLabel.Size = new System.Drawing.Size(50, 17);
            modelLabel.TabIndex = 8;
            modelLabel.Text = "Model:";
            // 
            // težinaLabel
            // 
            težinaLabel.AutoSize = true;
            težinaLabel.Location = new System.Drawing.Point(12, 141);
            težinaLabel.Name = "težinaLabel";
            težinaLabel.Size = new System.Drawing.Size(55, 17);
            težinaLabel.TabIndex = 10;
            težinaLabel.Text = "Težina:";
            // 
            // cenaLabel
            // 
            cenaLabel.AutoSize = true;
            cenaLabel.Location = new System.Drawing.Point(12, 169);
            cenaLabel.Name = "cenaLabel";
            cenaLabel.Size = new System.Drawing.Size(45, 17);
            cenaLabel.TabIndex = 12;
            cenaLabel.Text = "Cena:";
            // 
            // datum_dolaskaLabel
            // 
            datum_dolaskaLabel.AutoSize = true;
            datum_dolaskaLabel.Location = new System.Drawing.Point(12, 198);
            datum_dolaskaLabel.Name = "datum_dolaskaLabel";
            datum_dolaskaLabel.Size = new System.Drawing.Size(106, 17);
            datum_dolaskaLabel.TabIndex = 14;
            datum_dolaskaLabel.Text = "Datum dolaska:";
            // 
            // vozila_dbDataSet
            // 
            this.vozila_dbDataSet.DataSetName = "vozila_dbDataSet";
            this.vozila_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table_VozilaBindingSource
            // 
            this.table_VozilaBindingSource.DataMember = "Table_Vozila";
            this.table_VozilaBindingSource.DataSource = this.vozila_dbDataSet;
            // 
            // table_VozilaTableAdapter
            // 
            this.table_VozilaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Table_VozilaTableAdapter = this.table_VozilaTableAdapter;
            this.tableAdapterManager.UpdateOrder = Vozila_Projekat.vozila_dbDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // table_VozilaBindingNavigator
            // 
            this.table_VozilaBindingNavigator.AddNewItem = null;
            this.table_VozilaBindingNavigator.BindingSource = this.table_VozilaBindingSource;
            this.table_VozilaBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.table_VozilaBindingNavigator.DeleteItem = null;
            this.table_VozilaBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.table_VozilaBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.table_VozilaBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.table_VozilaBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.table_VozilaBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.table_VozilaBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.table_VozilaBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.table_VozilaBindingNavigator.Name = "table_VozilaBindingNavigator";
            this.table_VozilaBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.table_VozilaBindingNavigator.Size = new System.Drawing.Size(859, 27);
            this.table_VozilaBindingNavigator.TabIndex = 0;
            this.table_VozilaBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // table_VozilaDataGridView
            // 
            this.table_VozilaDataGridView.AllowUserToAddRows = false;
            this.table_VozilaDataGridView.AllowUserToDeleteRows = false;
            this.table_VozilaDataGridView.AllowUserToOrderColumns = true;
            this.table_VozilaDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.table_VozilaDataGridView.AutoGenerateColumns = false;
            this.table_VozilaDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.table_VozilaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.table_VozilaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.table_VozilaDataGridView.DataSource = this.table_VozilaBindingSource;
            this.table_VozilaDataGridView.Location = new System.Drawing.Point(12, 249);
            this.table_VozilaDataGridView.Name = "table_VozilaDataGridView";
            this.table_VozilaDataGridView.ReadOnly = true;
            this.table_VozilaDataGridView.RowHeadersWidth = 51;
            this.table_VozilaDataGridView.RowTemplate.Height = 24;
            this.table_VozilaDataGridView.Size = new System.Drawing.Size(835, 190);
            this.table_VozilaDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Kategorija";
            this.dataGridViewTextBoxColumn2.HeaderText = "Kategorija";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Marka";
            this.dataGridViewTextBoxColumn3.HeaderText = "Marka";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Model";
            this.dataGridViewTextBoxColumn4.HeaderText = "Model";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Težina";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "#,##\" kg\"";
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn5.HeaderText = "Težina";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Cena";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "#,##0.00 €";
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn6.HeaderText = "Cena";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Datum dolaska";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn7.HeaderText = "Datum dolaska";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // markaTextBox
            // 
            this.markaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table_VozilaBindingSource, "Marka", true));
            this.markaTextBox.Location = new System.Drawing.Point(124, 82);
            this.markaTextBox.Name = "markaTextBox";
            this.markaTextBox.Size = new System.Drawing.Size(232, 22);
            this.markaTextBox.TabIndex = 7;
            // 
            // modelTextBox
            // 
            this.modelTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table_VozilaBindingSource, "Model", true));
            this.modelTextBox.Location = new System.Drawing.Point(124, 110);
            this.modelTextBox.Name = "modelTextBox";
            this.modelTextBox.Size = new System.Drawing.Size(232, 22);
            this.modelTextBox.TabIndex = 9;
            // 
            // tezinaTextBox
            // 
            this.tezinaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table_VozilaBindingSource, "Težina", true));
            this.tezinaTextBox.Location = new System.Drawing.Point(124, 138);
            this.tezinaTextBox.Name = "tezinaTextBox";
            this.tezinaTextBox.Size = new System.Drawing.Size(232, 22);
            this.tezinaTextBox.TabIndex = 11;
            // 
            // cenaTextBox
            // 
            this.cenaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table_VozilaBindingSource, "Cena", true));
            this.cenaTextBox.Location = new System.Drawing.Point(124, 166);
            this.cenaTextBox.Name = "cenaTextBox";
            this.cenaTextBox.Size = new System.Drawing.Size(232, 22);
            this.cenaTextBox.TabIndex = 13;
            // 
            // datum_dolaskaDateTimePicker
            // 
            this.datum_dolaskaDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.table_VozilaBindingSource, "Datum dolaska", true));
            this.datum_dolaskaDateTimePicker.Location = new System.Drawing.Point(124, 194);
            this.datum_dolaskaDateTimePicker.Name = "datum_dolaskaDateTimePicker";
            this.datum_dolaskaDateTimePicker.ShowCheckBox = true;
            this.datum_dolaskaDateTimePicker.Size = new System.Drawing.Size(232, 22);
            this.datum_dolaskaDateTimePicker.TabIndex = 15;
            // 
            // dodajButton
            // 
            this.dodajButton.Location = new System.Drawing.Point(405, 110);
            this.dodajButton.Name = "dodajButton";
            this.dodajButton.Size = new System.Drawing.Size(97, 40);
            this.dodajButton.TabIndex = 16;
            this.dodajButton.Text = "Dodaj";
            this.dodajButton.UseVisualStyleBackColor = true;
            this.dodajButton.Click += new System.EventHandler(this.dodajButton_Click);
            // 
            // izbrisiButton
            // 
            this.izbrisiButton.Location = new System.Drawing.Point(508, 110);
            this.izbrisiButton.Name = "izbrisiButton";
            this.izbrisiButton.Size = new System.Drawing.Size(97, 40);
            this.izbrisiButton.TabIndex = 17;
            this.izbrisiButton.Text = "Izbriši";
            this.izbrisiButton.UseVisualStyleBackColor = true;
            this.izbrisiButton.Click += new System.EventHandler(this.izbrisiButton_Click);
            // 
            // sacuvajButton
            // 
            this.sacuvajButton.Location = new System.Drawing.Point(611, 110);
            this.sacuvajButton.Name = "sacuvajButton";
            this.sacuvajButton.Size = new System.Drawing.Size(97, 40);
            this.sacuvajButton.TabIndex = 18;
            this.sacuvajButton.Text = "Sačuvaj";
            this.sacuvajButton.UseVisualStyleBackColor = true;
            this.sacuvajButton.Click += new System.EventHandler(this.sacuvajButton_Click);
            // 
            // exportButton
            // 
            this.exportButton.Location = new System.Drawing.Point(714, 110);
            this.exportButton.Name = "exportButton";
            this.exportButton.Size = new System.Drawing.Size(97, 40);
            this.exportButton.TabIndex = 19;
            this.exportButton.Text = "Export";
            this.exportButton.UseVisualStyleBackColor = true;
            this.exportButton.Click += new System.EventHandler(this.exportButton_Click);
            // 
            // kategorijaComboBox
            // 
            this.kategorijaComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table_VozilaBindingSource, "Kategorija", true));
            this.kategorijaComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.kategorijaComboBox.FormattingEnabled = true;
            this.kategorijaComboBox.Items.AddRange(new object[] {
            "-Izaberite kategoriju-",
            "Automobil",
            "Bager",
            "Kamion",
            "Motor"});
            this.kategorijaComboBox.Location = new System.Drawing.Point(124, 54);
            this.kategorijaComboBox.Name = "kategorijaComboBox";
            this.kategorijaComboBox.Size = new System.Drawing.Size(232, 24);
            this.kategorijaComboBox.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 451);
            this.Controls.Add(this.kategorijaComboBox);
            this.Controls.Add(this.exportButton);
            this.Controls.Add(this.sacuvajButton);
            this.Controls.Add(this.izbrisiButton);
            this.Controls.Add(this.dodajButton);
            this.Controls.Add(kategorijaLabel);
            this.Controls.Add(markaLabel);
            this.Controls.Add(this.markaTextBox);
            this.Controls.Add(modelLabel);
            this.Controls.Add(this.modelTextBox);
            this.Controls.Add(težinaLabel);
            this.Controls.Add(this.tezinaTextBox);
            this.Controls.Add(cenaLabel);
            this.Controls.Add(this.cenaTextBox);
            this.Controls.Add(datum_dolaskaLabel);
            this.Controls.Add(this.datum_dolaskaDateTimePicker);
            this.Controls.Add(this.table_VozilaDataGridView);
            this.Controls.Add(this.table_VozilaBindingNavigator);
            this.MinimumSize = new System.Drawing.Size(877, 498);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vozila_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.table_VozilaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.table_VozilaBindingNavigator)).EndInit();
            this.table_VozilaBindingNavigator.ResumeLayout(false);
            this.table_VozilaBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table_VozilaDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private vozila_dbDataSet vozila_dbDataSet;
        private System.Windows.Forms.BindingSource table_VozilaBindingSource;
        private vozila_dbDataSetTableAdapters.Table_VozilaTableAdapter table_VozilaTableAdapter;
        private vozila_dbDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator table_VozilaBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView table_VozilaDataGridView;
        private System.Windows.Forms.TextBox markaTextBox;
        private System.Windows.Forms.TextBox modelTextBox;
        private System.Windows.Forms.TextBox tezinaTextBox;
        private System.Windows.Forms.TextBox cenaTextBox;
        private System.Windows.Forms.DateTimePicker datum_dolaskaDateTimePicker;
        private System.Windows.Forms.Button dodajButton;
        private System.Windows.Forms.Button izbrisiButton;
        private System.Windows.Forms.Button sacuvajButton;
        private System.Windows.Forms.Button exportButton;
        private System.Windows.Forms.ComboBox kategorijaComboBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}

